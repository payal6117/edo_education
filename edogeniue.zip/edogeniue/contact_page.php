<?php require("view/header.php"); ?>

    <section class=" main_section  contact_page_section" id="">
        <h1 class="heading">Contact Us</h1>

        <div class=" d_grid content ">
                <div class="item">
                    <a href="#"><i class="fa fa-phone" aria-hidden="true"></i> +91 2222 2222 2222 </a>
                </div>
                <div class="item">
                   <a href="#"> <i class="fa fa-envelope" aria-hidden="true"></i>  contactus@edugenius.in</a>
                </div>
        </div>
    </section>


    <section class="main_section admision_form d_grid main ">
        <div class="item">
            <div class="swiper banner_swiper swipee " >
                <div class="swiper-wrapper">
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg)"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                  <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
                </div>
                <!-- <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div> -->
                
            </div>
        </div>
        <div class="item">
            <div class="item form_left">
                <h1 class="heading" >Request Admissions Information</h1>
                <form action="#" class="form">
                   <ul>
                       <li><input type="text" name="fname" id="username" placeholder="Your Name" required></li>
                       <li><input type="text" name="fname" id="phoneno" placeholder="Your Phone No" required></li>
                       <li><input type="text" name="fname" id="email" placeholder="Your Email" required></li>
                       <li><input type="text" name="fname" id="school" placeholder="School" required></li>
                  
                       <div class="choose_class">
                            <select name="" id="" required>
                                <option value="">Choose Your Class</option>
                                <option value="seven">7</option>
                                <option value="eight">8</option>
                                <option value="nine">9</option>
                                <option value="ten">10</option>
                            </select>
                       </div>
    
                       <li><textarea name="" id="" cols="30" rows="10" placeholder="Your message (optional)" required></textarea></li>
                  
                       <li class="common_btn form_submit_btn"><button type="submit" >Submit</button></li>
                    </ul>
                </form>
             </div>
        </div>
    </section>


    <section class=" main_section  address_page_section" id="">
        <h1 class="heading">Main Head Office:</h1>

        <div class=" d_grid address_content ">
                <div class="item"> 
                    <ul>
                        <li><h1> <i class="fa fa-location-arrow " aria-hidden="true"></i> 
                            Lorem ipsum dolor sit amet consectetur
                           </h1>
                            <p>
                                A-100, Ground Floor, Ashok Nagar,
                                Near Sivaji park
                                Patna - 80001
                            </p>
                        </li>

                        <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i>  +91 80109 13515</a></li>
                    
                        <li>
                             <a href="#"> <i class="fa fa-envelope" aria-hidden="true"></i>  contactus@edugenius.in</a>
                        </li>

                    </ul>
                   

                </div>
                <div class="item">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7197.082478020012!2d85.14390457518087!3d25.58692533486545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ed587e3c34777f%3A0x22b2bbda272c2a8!2sAshok%20Nagar%2C%20Lohia%20Nagar%2C%20Patna%2C%20Bihar%20800020!5e0!3m2!1sen!2sin!4v1647941006945!5m2!1sen!2sin" width="" height="" style="border:0;" allowfullscreen="" loading="lazy" class="locate_map"></iframe>
                </div>
        </div>
    </section>

   
</div>


    

    <script>
        var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });

    </script>

    
<?php require("view/footer.php"); ?>
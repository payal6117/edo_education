<?php require("view/header.php"); ?>


<section class=" main_section photo_section " id="photo_section">
    <h1 class="heading">Photos</h1>

    <div class="grid_img  ">
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
        <div class="vdo_item">
            <img src="./img/22.jpg" alt="photos">
        </div>
    </div>
</section>
<?php require("view/header.php"); ?>



<section class="main_section bank_detail_section">
    <h1 class="heading">Fee Payment</h1>
    <div class="content">
        <div class="card">
            <div class="bank_item">
                <h2>Name Of Bank : <i class="fa fa-credit-card-alt" aria-hidden="true"></i></h2>
                <p>Bank Of India</p>
            </div>

            <div class="bank_item">
                <h2>Account number :</h2>
                <p>3333 3333 333333</p>
            </div>

            <div class="bank_item">
                <h2>Account Holder Number :</h2>
                <p>3333 3333 333333</p>
            </div>
        </div>
    </div>
</section>

<?php require("view/footer.php"); ?>

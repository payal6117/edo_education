 <?php require("view/header.php"); ?>

 <!-- <div class="position-absolute arrow_up quick_enquiry_4" > 
    <li>
        <a href="./#top" class="quick_enquiry_link_arrow_up"> 
        <i class="fa fa-arrow-up" aria-hidden="true"></i>
     </a>
    </li>
</div> -->

  
  <!-- -------------------------------------------- banner section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  <section class="banner " id="top">
      <div class="swiper banner_swiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide  "  style="background-image: url(./img/22.jpg); height: 100vh;"> </div>
            <div class="swiper-slide"  style="background-image: url(./img/22.jpg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/22.jpg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/22.jpg); height: 100vh;"></div>
            <div class="swiper-slide"  style="background-image: url(./img/22.jpg); height: 100vh;"></div>
          </div>
          <div class="swiper-button-next slider_icon"></div>
          <div class="swiper-button-prev slider_icon"></div>
          
      </div>
  </section>

  <!-- --------------------------------------------- Quick Links section --------------------------------------------------------------------------------------------- -->

  <section class=" main_section quick_link__section ">
      <!-- <h1 class="heading">Quick Links</h1> -->

      <div class="quick_item quick_link_d_grid ">
          <div class="item">
              <a href="#landing_form_page" >Register for courses <br>   <i class="fa fa-cloud-download" aria-hidden="true"></i>    </a >
          </div>
          <div class="item">
              <a href="./edugenius.php" >scholorship tests <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="./edugenius.php" >test results <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="#landing_form_page" >faq <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
              <a href="#landing_form_page" >downloads <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
          </div>
          <div class="item">
            <a href="#landing_form_page" >Blogs <br>  <i class="fa fa-cloud-download" aria-hidden="true"></i> </a >
        </div>
      </div>
  </section>  

  <!-- -------------------------------------------- about section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
    <section class=" main_section about__section  " id="testresult">
        <div class="about_content d_grid ">
            <div class="item item_left">
                <img src="./img/1.jpg" alt="#" id="imgg about_img" >
            </div>
            <div class="item item_right">
                <div class="right_content">
                    <h1 class="heading" id="about_heading" >About Our Institute</h1>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. consequuntur quibusdam enim expedita sed nesciunt incidunt accusamus adipisci officia libero laboriosam!
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. consequuntur quibusdam enim expedita sed nesciunt incidunt accusamus adipisci officia libero laboriosam!
                    </p>

                    <ul>
                        <li><button class="common_btn">
                            <a href="about_page.php" >read more</a>
                        </button></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

   <!-- -------------------------------------------- WHY ? section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->

  <section class=" main_section why_choose_us__section ">
      <div class=" d_grid ">
         
          <div class="item item_right">
          <h1 class="heading " id="" >Edugenius Why?</h1>
              <div class="right_content">
                  
                  <div class="title_text">
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing</p> 
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                  </div>


                  <ul>
                      <div class="why_choose_us_btn">
                          <li><button class="common_btn">
                              <a href="#" >read more</a>
                          </button></li>
                          <li><button class="common_btn apply_now_btn">
                              <a href="#" >ADMISSIONS (APPLY ONLINE)</a>
                          </button></li>
                      </div>
                  </ul>
              </div>
          </div>

          <div class="item item_left ">
              <iframe class="why_choose_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
      </div>
 </section>





     <!-- -------------------------------------------- admission center section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  <section class=" main_section admission__center  ">
      <div class="content d_grid">
            <div class="item">
              <div class="text_content">
                  <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href=""> Admission Center</a> </h2>
                  <p class="course_descript">
                      Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                  </p>

              </div>
          </div>
          
          <div class="item">
              <div class="text_content">
                  <i class="fa fa-firefox" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Certification</a> </h2>
                  <h2 class="course_name"> <a href="#"></a> </h2>
                  <p class="course_descript">
                      Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                  </p>

              </div>
          </div>

          <div class="item">
              <div class="text_content">
                  <i class="fa fa-mortar-board" aria-hidden="true"></i>
                  <h2 class="course_name"> <a href="#">Certification</a> </h2>
                  <p class="course_descript">
                      Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                  </p>

              </div>
          </div>
      </div>
  </section>

  <!-- --------------------------------------------- our courses section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->
  
  <section class=" main_section courses__section ">
      <h1 class="heading">Our Courses</h1>
      <div class="course_content d_grid">

        <div class="course_item">
            <img src="./img/22.jpg" alt="#">
            
            <div class="text_content">
                <h2 class="course_name" id="neet_it_course">Foundation Courses For NEET & IIT-JEE</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem     
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="#" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <img src="./img/22.jpg" alt="#">
            
            <div class="text_content">
                <h2 class="course_name"> Class 7th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="#" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <img src="./img/22.jpg" alt="#">
            
            <div class="text_content">
                <h2 class="course_name"> Class 8th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="#" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <img src="./img/22.jpg" alt="#">
            
            <div class="text_content">
                <h2 class="course_name"> Class 9th</h2>
                
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="#" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>

        <div class="course_item">
            <img src="./img/22.jpg" alt="#">
            
            <div class="text_content">
                <h2 class="course_name"> Class 10th</h2>
                <p class="course_descript">
                    Lorem ipsum dolor sit amet consectetur Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel necessitatibus, 
                </p>

                <div class="course_btn">
                    <ul >
                        <li><button class="common_btn">
                            <a href="#" >Read More</a>
                        </button></li>
                    </ul>   
                </div>
            </div>
        </div>
      </div>
 
    </div>
  </section>




  <!-- ---------------------------------------------  Form section 
 ------------------------------------------------------------------------------------------ -->
<section class="main_section admision_form d_grid main ">
    <div class="item">
        <div class="swiper banner_swiper swipee " >
            <div class="swiper-wrapper">
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg)"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
              <div class="swiper-slide "  style="background-image: url(./img/22.jpg); ;"></div>
            </div>
            <!-- <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div> -->
            
        </div>
    </div>
    <div class="item" id="landing_form_page">
        <div class="item form_left">
            <h1 class="heading" >Request Admissions Information</h1>
            <form action="#" class="form">
               <ul>
                   <li><input type="text" name="fname" id="username" placeholder="Your Name" required></li>
                   <li><input type="text" name="fname" id="phoneno" placeholder="Your Phone No" required></li>
                   <li><input type="text" name="fname" id="email" placeholder="Your Email" required></li>
                   <li><input type="text" name="fname" id="school" placeholder="School" required></li>
              
                   <div class="choose_class">
                        <select name="" id="" required>
                            <option value="">Choose Your Class</option>
                            <option value="seven">7</option>
                            <option value="eight">8</option>
                            <option value="nine">9</option>
                            <option value="ten">10</option>
                        </select>
                   </div>

                   <li><textarea name="" id="" cols="30" rows="10" placeholder="Your message (optional)" required></textarea></li>
              
                   <li class="common_btn form_submit_btn"><button type="submit" >Submit</button></li>
                </ul>
            </form>
         </div>
    </div>
</section>

  <!-- --------------------------------------------- Youtube Videos section 
 ------------------------------------------------------------------------------------------ -->

    <section class=" main_section youtube_vdo_section ">
        <div class=" d_grid  youtube_vdo_section_d_grid">
            <div class="item">
                <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <div class="item">
                <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <div class="item">
                <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
            
            <div class="item">
                <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
            </div>
        
        </div>
    </section>
  
  <!-- --------------------------------------------- Blog section 
 ------------------------------------------------------------------------------------------ -->

 <section class="main_section testimonial_section   ">
    <h1 class="heading text-left" id="" >Our testimonial</h1>
     <div class="testimonial_content">
      <div class="swiper testimonial_swiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide item " > 
                <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                <div class="content">
                    <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                    <div class="testimonial_caption d_grid  ">
                        <img src="./img/6.jpg" class="caption_img" alt="">
                        <div class="caption_name">
                            <p>Avni Amit Kumar</p>
                             <p> DAV Public School, Ghaziabad</p>
                         </div>
                     
                    </div>
                </div>
             </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                   <div class="content">
                       <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <img src="./img/6.jpg" class="caption_img" alt="">
                           <div class="caption_name">
                               <p>Avni Amit Kumar</p>
                                <p> DAV Public School, Ghaziabad</p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                   <div class="content">
                       <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <img src="./img/6.jpg" class="caption_img" alt="">
                           <div class="caption_name">
                               <p>Avni Amit Kumar</p>
                                <p> DAV Public School, Ghaziabad</p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                   <div class="content">
                       <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <img src="./img/6.jpg" class="caption_img" alt="">
                           <div class="caption_name">
                               <p>Avni Amit Kumar</p>
                                <p> DAV Public School, Ghaziabad</p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                   <div class="content">
                       <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <img src="./img/6.jpg" class="caption_img" alt="">
                           <div class="caption_name">
                               <p>Avni Amit Kumar</p>
                                <p> DAV Public School, Ghaziabad</p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                     <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

                   <div class="content">
                       <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                       <div class="testimonial_caption d_grid  ">
                           <img src="./img/6.jpg" class="caption_img" alt="">
                           <div class="caption_name">
                               <p>Avni Amit Kumar</p>
                                <p> DAV Public School, Ghaziabad</p>
                            </div>
                        
                       </div>
                   </div>
            </div>
            <div class="swiper-slide item ">
                <img class="testimonial_image" src="./img/2.jpg" alt="testimonialImage">

              <div class="content">
                  <P>“Excellent institute with intellectual teachers who will help you to clear your doubts and understand all concepts properly. I had a wonderful experience at Edugenius. I scored almost 100 in all subjects taken in Edugenius. So I can definitely say that Edugenius will Definitely help you to crack boards and excel in studies.” </P>

                  <div class="testimonial_caption d_grid  ">
                      <img src="./img/6.jpg" class="caption_img" alt="">
                      <div class="caption_name">
                          <p>Avni Amit Kumar</p>
                           <p> DAV Public School, Ghaziabad</p>
                       </div>
                   
                  </div>
              </div>
            </div>   
           
            </div>

          </div>
        
     </div>
 </section>








































 <script>
            var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });


            var swiper = new Swiper(".testimonial_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: false,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 1000,
                    disableOnInteraction: true,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                    768: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 10,
                    },
                },
            });
        </script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>



<?php require("view/footer.php"); ?>

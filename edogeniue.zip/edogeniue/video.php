<?php require("view/header.php"); ?>


<section class=" main_section  grid_video " id="">
    <h1 class="heading">Video Lectures</h1>

    <div class="d_grid  ">
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
       <div class="vdo_item">
            <iframe class="youtube_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
       </div>
    </div>
</section>
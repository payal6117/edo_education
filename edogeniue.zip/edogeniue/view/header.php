<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edozineus</title>


   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

   <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
   <link rel="stylesheet" href="./css/header.css">
   <link rel="stylesheet" href="./css/top_section.css.css">
   <link rel="stylesheet" href="./css/page.css">
   <link rel="stylesheet" href="./css/style.css">
</head>
<body>


 <!-- Section: Header -->
 <header class="header" id="top" >

      <nav class=" dis_none" id="" >
         <div class="nav_top">

         
            <div class="content "  >
                <ul class=" ">
                    <li class="d_none" ><a href="contact_page.php">Registration</a></li>
                    <li class="d_none"> <a href="contact_page.php">Learning Portal For Students </a></li>
                    <li class="d_none"><a href="contact_page.php">Portal For Parents</a></li>
                    <li class="d_none"><a href="./video.php">Video Lectures</a> </li>
                    <li class="d_none"><a href="contact_page.php">Alumni Login</a></li>
                </ul>
            </div>

         </div>
        </nav>

      <section class="header_container    ">
         
         <div class="header_content">

            <!-- logo -->
               <a href="index.php" class="brand">Edugenius</a>
            <!-- logo end -->
            
            <!-- NAVBAR BTN START  -->
               <button type="button" class="burger" id="burger">
                  <span class="burger-line"></span>
                  <span class="burger-line"></span>
                  <span class="burger-line"></span>
                  <span class="burger-line"></span>
               </button>
            <!-- NAVBAR BTN  END -->

            <span class="overlay" id="overlay"></span>
            <nav class="navbar" id="navbar">
               <ul class="menu">
                  

                     <li class="menu-item active_bg" id="d_none"  ><a href="#">Registration</a></li>
                     <li class="menu-item active_bg" id="d_none"> <a href="#">Learning Portal For Students </a></li>
                     <li class="menu-item active_bg" id="d_none"><a href="#">Portal For Parents</a></li>
                     <li class="menu-item active_bg" id="d_none"><a href="#">Video Lectures</a> </li>
                     <li class="menu-item active_bg" id="d_none"><a href="#">Alumni Login</a></li>
                     <li class="menu-item"  id=""><a href="./index.php">Home</a></li>
                     
                     <li class="menu-item"><a href="./about_page.php">About</a></li>
                     <li class="menu-item menu-item-child">
                        
                     <!-- for submenu -->
                        <a href="#" data-toggle="sub-menu">Study Materials<i class="expand plus_icon"></i></a>
                     <!-- for submenu -->

                     <!-- <a href="#" data-toggle="sub-menu">Study Materials</a> -->
                        <ul class="sub-menu">
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 7</a></li>
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 8</a></li>
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 9</a></li>
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 10</a></li>
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 11</a></li>
                           <li class="sub_menu_item_li menu-item"><a href="./class_6.php">Class 12</a></li>
                        </ul>
                  </li>
                  <li class="menu-item menu-item-child">
                     <!-- <a href="#" data-toggle="sub-menu">Planning <i class="expand plus_icon"></i></a> -->
                     <!-- <a href="#" data-toggle="sub-menu">Enquiry form </a> -->
                     <!-- <a href="#" data-toggle="sub-menu">Blogs </a> -->
                     <!-- <ul class="sub-menu">
                        <li class="sub_menu_item_li menu-item "><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                     </ul> -->
                  </li>

                  <li class="menu-item"><a href="./photo_page.php">Photos</a></li>

                  <!-- <li class="menu-item"><a href="./fee_page.php">Fee payments</a></li> -->

                  <li class="menu-item menu-item-child">
                     <!-- <a href="#" data-toggle="sub-menu">Projects <i class="expand plus_icon"></i></a> -->
                     <a href="./result_reward.php" data-toggle="sub-menu" >Results & Rewards</a>
                     <!-- <ul class="sub-menu">
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                        <li class="sub_menu_item_li menu-item"><a href="#">SubMenu</a></li>
                     </ul> -->
                  </li>
                  <li class="menu-item"><a href="./contact_page.php">Contact Us</a></li>
               </ul>
            </nav>
         </div>
      </section>
   </header>



       <!-- --------------------------------- fixed Social icon section --------------------------------------
    -------------------------------------------------------------------------------------------- -->
    <section class="fixed_icons">
        <div class="fixed-top  ">
            <div class="position-relative ">
                <div class="position-absolute quick_enquiry "> 
                    <li><a href="#" class="quick_enquiry_link"> 
                      <a href="#">Addmissions Now</a>
                    </li>
                </div>
                <div class="position-absolute quick_enquiry social_icon quick_enquiry_2" > 
                    <li><a href="#" class="quick_enquiry_link"> 
                      <a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                    </li>
                </div>
                <div class="position-absolute quick_enquiry social_icon quick_enquiry_3" > 
                    <li><a href="#" class="quick_enquiry_link"> 
                      <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                </div>

                <div class="position-absolute arrow_up quick_enquiry_4" > 
                    <li>
                        <a href="#top" class="quick_enquiry_link_arrow_up"> 
                        <i class="fa fa-arrow-up" aria-hidden="true"></i>
                     </a>
                    </li>
                </div>
            </div>
        </div>
    </section>


      <script defer src="../js/script.js"></script>
      <script defer src="./js/script.js"></script>
   <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
   <!-- jquery link -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 
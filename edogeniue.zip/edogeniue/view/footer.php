<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edozineus</title>


   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
   <link rel="stylesheet" href="./css/style.css">
</head>
<body>





<footer class=" footer_section " >
    <div class="content d_grid">
        <div class="item  about_logo_sec">
            
                <a href="index.php" class="brand">Edugenius</a>
                <p class="about_edo_text"  >EDUGENIUS, A Leading Consultancy And The Best Coaching For 8th To 12th Standard Candidates, Is There To Provide Expert Guidance, Consultancy And Counseling To Aspirants For A Better Career And Future</p>
           
        </div>
    
        <div class="item navigation_links">
            <ul>
                <li class="nav_links"><h1>Navigation Links</h1></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>About</a></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>Enquiry Form</a></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>Photos</a></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>Fee Payments</a></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>Results & Rewards</a></li>
                <li class="nav_links"><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i>Contact Us</a></li>
            </ul>
        </div>
    
        <div class="item navigation_links">
            <ul>
                <li class="nav_links"><h1>STUDY MATERIALS</h1></li>
                <li class="nav_links"><a href="#"> <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 8th </a></li>
                <li class="nav_links"><a href="#"> <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 9th </a></li>
                <li class="nav_links"><a href="#"> <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 10th </a></li>
                <li class="nav_links"><a href="#"> <i class="fa fa-arrow-right" aria-hidden="true"></i>Class 11th </a></li>
                <li class="nav_links"><a href="#"> <i class="fa fa-arrow-right" aria-hidden="true"></i> Class 12th </a></li>
            </ul>
        </div>
    
        <div class="item">
            <ul>
                <li class="socia_links"><h1>Get In Touch</h1></li>
                 <span class="social_media">
                    <li class="socia_links"><a href="#"><i class="fa  fa-whatsapp icons " aria-hidden="true"></i></a></li>
                    <li class="socia_links"><a href="#"><i class="fa  fa-youtube  icons "  aria-hidden="true"></i></a></li>
                    <li class="socia_links"><a href="#"><i class="fa  fa-mail     icons " 
                        aria-hidden="true"></i></a></li>
                 </span>

                 <div class="location">
                     <div>
                         <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptates repellendus fuga quasi ea cumque sequi aut, quaerat, totam doloremque!</p>
                     </div>
                 </div>
            </ul>
        </div>

        <!-- <div class="item">d</div> -->
    </div>

</footer>


</body>
</html>
<?php require("view/header.php"); ?>

    <section class=" main_section  address_page_section class_section" id="">
        <h1 class="heading">Class VI</h1>

        <div class="content">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni ipsum optio nulla esse reprehenderit quae dolorum numquam porro deserunt est, quibusdam beatae recusandae similique, totam, aspernatur aliquam? Hic aperiam tempora delectus quos? Sit amet reprehenderit deserunt voluptas ullam animi molestiae molestias laboriosam, enim at nemo fuga odit eaque, veniam officiis?</p>
        </div>

        <div class="content_image d_grid grid_img">
            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>
            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

            <div class="class_item">
                <img src="./img/2.jpg" alt="">
                <p>Subject Name</p>
            </div>

        </div>
    </section>
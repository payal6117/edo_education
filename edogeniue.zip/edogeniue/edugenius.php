<?php require("view/header.php"); ?>



<section class="main_section edo_common">
    <div class="d_grid">
        <div class="item img_item">
            <img src="./img/22.jpg" alt="">
        </div>
        <div class="item">
            
            <h1><i class="fa fa-pencil-square-o" aria-hidden="true"></i>scholarship test</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iusto enim sint consequatur tenetur alias eaque ipsa animi rerum, pariatur corrupti quo inventore libero explicabo, consequuntur veritatis tempore, possimus ducimus. Distinctio amet eos facilis aperiam voluptatum facere ipsa culpa? Sunt, aliquam!</p>
        </div>
    </div>
</section>



<!-- <section class="main_section edo_common" >
    <div class="d_grid" id="testresult">
        <div class="item img_item">
            <img src="./img/22.jpg" alt="">
        </div>
        <div class="item">
            
            <h1><i class="fa fa-pencil-square-o" aria-hidden="true"></i>TEST RESULTS</h1>


            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iusto enim sint consequatur tenetur alias eaque ipsa animi rerum, pariatur corrupti quo inventore libero explicabo, consequuntur veritatis tempore, possimus ducimus. Distinctio amet eos facilis aperiam voluptatum facere ipsa culpa? Sunt, aliquam!</p>
        </div>
    </div>
</section> -->




FAQ
DOWNLOADS
BLOGS -->

<?php require("view/header.php"); ?>

    <section class=" main_section about__section about_page_section" id="about_page_section">
        <h1 class="heading">About Us</h1>
        
        <div class="course_content about_content d_grid   ">
            <div class="item item_left">
                <img src="./img/1.jpg" alt="#" id="imgg about_img" >
            </div>
            
            <div class="item item_right">
                <div class="right_content">
                    <h1 class="heading" id="about_heading" >About Our Institute</h1>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. consequuntur quibusdam enim expedita sed nesciunt incidunt accusamus adipisci officia libero laboriosam!
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. consequuntur quibusdam enim expedita sed nesciunt incidunt accusamus adipisci officia libero laboriosam!
                    </p>

                    <ul>
                        <li><button class="common_btn apply_now_btn">
                            <a href="#" > APPLY ONLINE</a>
                        </button></li>
                    </ul>
                </div>
            </div>
        </div>



        <div class="course_content about_content d_grid   ">
            <div class="item item_left d_heading">
                <h2 class="heading" id="" >
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellat, et odio perferendis autem ab blanditiis possimus corrupti aliquid earum ex?
                </h2>
            </div>
            
            <div class="item item_right">
                <div class="right_content">
                    
                    <div class="item">
                        <div class="swiper banner_swiper swipee " >
                            <div class="swiper-wrapper">
                              <div class="swiper-slide ">
                                  <img src="./img/2.jpg" alt="">
                              </div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                              <div class="swiper-slide " >  <img src="./img/2.jpg" alt=""></div>
                            </div>
                            <!-- <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div> -->
                            
                        </div>
                </div>
            </div>
        </div>
        </div>
    </section>


     <!-- -------------------------------------------- WHY ? section ---------------------------------------------------
  ----------------------------------------------------------------------------------------------------------------------- -->

  <section class=" main_section why_choose_us__section   " id="why_choose_us__section">
    <div class=" d_grid ">
       
        <div class="item item_right">
        <h1 class="heading " id="" >Edugenius Why?</h1>
            <div class="right_content">
                
                <div class="title_text">
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing</p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p>
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p> 
                      <p> Lorem ipsum dolor sit amet consectetur adipisicing </p>
                       
                </div>

            </div>
        </div>

        <div class="item item_left ">
            <iframe class="why_choose_vdo" width="" height="" src="https://www.youtube.com/embed/GvLIEiqxS6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
</section>

<section class="apply_now_section" id="apply_now_section">
    <div class="btn">

     <div class="para">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, illo dignissimos accusamus corporis earum architecto dolorem iure ut fugit explicabo illum sint! Deleniti libero culpa ea repellendus dolore voluptate non.</p>
     </div>
        

        <ul>
            <li><button class="common_btn apply_now_btn " id="about_apply_now">
                <a href="#" > APPLY ONLINE</a>
            </button></li>
        </ul>
    </div>
</section>




    <script>
        var swiper = new Swiper(".banner_swiper", {
                autoHeight: false,
                spaceBetween: 0,
                pagination: {
                clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1,
                        spaceBetween: 20,
                    },
                    768: {
                        slidesPerView: 1,
                        // spaceBetween: 40,
                    },
                    1024: {
                        slidesPerView: 1,
                        // spaceBetween: 50,
                    },
                },
            });

    </script>




<?php require("view/footer.php"); ?>
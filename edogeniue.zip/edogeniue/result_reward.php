<?php require("view/header.php"); ?>


<section class="main_section result_reward">
    <div class="rewardContainer bg-">
    <h1 class="heading">Results & Rewards</h1>

        <!-- <div class="bannerSection">
            <h1></h1>
        </div> -->
        <div class="coursesDetails">    
            <!-- <h1>YOUR RESULT AND REWARDS</h1> -->
            <div class="row1">
                
            <div class="row2">
                <div class="item">
                    <div class="card">
                        <i class="fa fa-id-badge rewardIcon" aria-hidden="true"></i>
                        <div class="card-body">
                          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum voluptates veritatis sint blanditiis ex corrupti nemo nulla commodi aliquid laudantium.</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-cube" aria-hidden="true"></i>
                        <div class="card-body">
                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. A quod iste unde commodi tempore impedit animi laudantium eius aut reiciendis!</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-bandcamp" aria-hidden="true"></i>
                        <div class="card-body">
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non tempora aspernatur dignissimos similique delectus ab enim commodi amet quisquam? Eaque?</p>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card">
                        <i class="fa fa-cubes" aria-hidden="true"></i>
                        <div class="card-body">
                           <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil natus molestias adipisci similique eligendi, odio labore voluptate iure doloremque facilis.</p>
                        </div>
                       
                    </div>
                </div>
            </div>

        </div>

    </div>
    </section>